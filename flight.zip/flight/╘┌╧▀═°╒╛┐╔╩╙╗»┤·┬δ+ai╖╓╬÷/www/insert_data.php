<?php
header('Content-Type: application/json');
include('db.php');

// 获取前端传来的数据
$location = $_POST['location'];
$sensor_id = $_POST['sensor_id'];
$sensor_type = $_POST['sensor_type'];
$value = $_POST['value'];
$unit = $_POST['unit'];

// 插入数据到数据库
$query = "INSERT INTO sensor_data (location, sensor_id, sensor_type, value, unit) 
          VALUES ('$location', '$sensor_id', '$sensor_type', '$value', '$unit')";

if ($conn->query($query) === TRUE) {
    echo json_encode(["message" => "Data inserted successfully"]);
} else {
    echo json_encode(["message" => "Error: " . $conn->error]);
}

$conn->close();
?>
