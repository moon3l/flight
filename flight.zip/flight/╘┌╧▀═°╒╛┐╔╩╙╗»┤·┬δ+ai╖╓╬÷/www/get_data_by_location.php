<?php
header('Content-Type: application/json');
include('db.php');

// 获取位置参数
$location = $_GET['location'] ?? '';

// 查询指定位置的数据
$query = "SELECT * FROM sensor_data WHERE location LIKE '%$location%' ORDER BY timestamp DESC";
$result = $conn->query($query);

$data = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    echo json_encode($data);
} else {
    echo json_encode(["message" => "No data found"]);
}

$conn->close();
?>
