<?php
header('Content-Type: application/json');

// 执行 Python 脚本
$command = escapeshellcmd('python3 ai_analysis.py');
$output = shell_exec($command);

// 返回 Python 脚本的输出
echo $output;
?>
