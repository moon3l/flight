<?php
$host = "localhost";  // 数据库主机
$username = "root";   // 数据库用户名
$password = "123456";       // 数据库密码
$dbname = "environment_monitoring";  // 数据库名称

// 创建数据库连接
$conn = new mysqli($host, $username, $password, $dbname);

// 检查连接
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
}
?>
