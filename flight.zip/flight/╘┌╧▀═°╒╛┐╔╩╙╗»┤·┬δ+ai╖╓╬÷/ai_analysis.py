import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt
import mysql.connector
import json

# 从MySQL数据库读取环境数据
def get_data_from_db():
    connection = mysql.connector.connect(
        host='localhost',
        user='root',
        password='password',
        database='environment_monitoring'
    )
    cursor = connection.cursor(dictionary=True)
    cursor.execute("SELECT * FROM sensor_data WHERE sensor_type = 'PM2.5' ORDER BY timestamp DESC LIMIT 100")
    data = cursor.fetchall()
    connection.close()
    return data

# 数据预处理
def preprocess_data(data):
    # 将数据转换为 pandas DataFrame
    df = pd.DataFrame(data)
    df['timestamp'] = pd.to_datetime(df['timestamp'])
    df['timestamp'] = df['timestamp'].apply(lambda x: x.timestamp())  # 转换为时间戳

    # 只保留 timestamp 和 value
    df = df[['timestamp', 'value']]
    return df

# 使用线性回归进行预测
def predict_pm25(df):
    # 拆分数据：X 为时间戳，y 为 PM2.5 值
    X = df['timestamp'].values.reshape(-1, 1)
    y = df['value'].values

    # 线性回归模型
    model = LinearRegression()
    model.fit(X, y)

    # 预测下一个时间点的 PM2.5
    future_timestamp = np.array([df['timestamp'].max() + 3600]).reshape(-1, 1)  # 下一小时
    predicted_value = model.predict(future_timestamp)

    return predicted_value[0]

# 生成预测结果并返回
def analyze_data():
    data = get_data_from_db()
    df = preprocess_data(data)
    predicted_pm25 = predict_pm25(df)

    # 返回预测结果
    return {'predicted_pm25': predicted_pm25, 'timestamp': df['timestamp'].max() + 3600}

# 执行分析并返回结果
result = analyze_data()
print(json.dumps(result, indent=4))
