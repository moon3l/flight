CREATE DATABASE environment_monitoring;
USE environment_monitoring;

CREATE TABLE sensor_data (
    id INT AUTO_INCREMENT PRIMARY KEY,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,  -- 数据采集时间
    sensor_id VARCHAR(100),                       -- 传感器标识
    sensor_type VARCHAR(100),                     -- 传感器类型（如PM2.5, CO2等）
    value DECIMAL(10, 2),                         -- 传感器值
    unit VARCHAR(50)                              -- 单位 (如 ppm, µg/m³, °C)
);
