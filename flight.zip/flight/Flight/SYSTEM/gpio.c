#include "gpio.h"
#include "stm32f4xx_hal.h"

// GPIO 初始化配置
void MX_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    __HAL_RCC_GPIOB_CLK_ENABLE(); // 使能 GPIOB 时钟

    // 配置 GPIO 引脚：例如输入输出引脚（例如，传感器电源控制）
    GPIO_InitStruct.Pin = GPIO_PIN_0 | GPIO_PIN_1;  // 配置引脚0和1
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;      // 推挽输出模式
    GPIO_InitStruct.Pull = GPIO_NOPULL;              // 不上拉
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;     // 低速
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);          // 初始化 GPIOB

    // 配置输入引脚：例如传感器信号读取
    GPIO_InitStruct.Pin = GPIO_PIN_2;                // 配置引脚2
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;          // 输入模式
    GPIO_InitStruct.Pull = GPIO_NOPULL;              // 不上拉
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);          // 初始化 GPIOB

    // 配置外部中断（例如按钮触发任务）
    GPIO_InitStruct.Pin = GPIO_PIN_3;                // 配置引脚3
    GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;     // 下降沿中断
    GPIO_InitStruct.Pull = GPIO_NOPULL;              // 不上拉
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);          // 初始化 GPIOB

    // 启用中断
    HAL_NVIC_EnableIRQ(EXTI3_IRQn);  // 使能外部中断 3
}
