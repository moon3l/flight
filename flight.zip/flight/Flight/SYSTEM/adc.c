#include "adc.h"
#include "stm32f4xx_hal.h"

// ADC1 端口定义（用于模拟传感器读取）
extern ADC_HandleTypeDef hadc1;

// ADC1 初始化配置函数
void MX_ADC1_Init(void)
{
    ADC_ChannelConfTypeDef sConfig = {0};

    hadc1.Instance = ADC1;
    hadc1.Init.Resolution = ADC_RESOLUTION_12B;  // 分辨率12位
    hadc1.Init.ScanConvMode = ADC_SCAN_DISABLE;   // 禁用扫描模式
    hadc1.Init.ContinuousConvMode = DISABLE;      // 禁用连续转换
    hadc1.Init.DiscontinuousConvMode = DISABLE;   // 禁用不连续转换
    hadc1.Init.ExternalTrigConv = ADC_EXTERNALTRIGCONV_T1_CC1; // 外部触发设置
    hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;   // 数据右对齐
    hadc1.Init.NbrOfConversion = 1;               // 单通道采样

    if (HAL_ADC_Init(&hadc1) != HAL_OK)
    {
        Error_Handler();  // 初始化失败时的错误处理
    }

    // 配置 ADC 通道
    sConfig.Channel = ADC_CHANNEL_1;             // 使用通道 1（可根据实际传感器修改）
    sConfig.Rank = 1;                             // 第一通道
    sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES; // 采样时间设置
    if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
    {
        Error_Handler();  // 配置通道失败时的错误处理
    }
}

// ADC 读取函数
uint32_t ADC_Read(void)
{
    // 启动 ADC 转换
    HAL_ADC_Start(&hadc1);
    // 等待转换完成
    if (HAL_ADC_PollForConversion(&hadc1, 100) == HAL_OK)
    {
        return HAL_ADC_GetValue(&hadc1);  // 获取 ADC 值
    }
    return 0;
}
