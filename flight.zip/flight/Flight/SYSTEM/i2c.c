#include "i2c.h"
#include "stm32f4xx_hal.h"

// I2C1 端口定义（用于传感器通信）
extern I2C_HandleTypeDef hi2c1;

// I2C1 初始化配置函数
void MX_I2C1_Init(void)
{
    hi2c1.Instance = I2C1;
    hi2c1.Init.ClockSpeed = 100000;            // I2C时钟速度100kHz
    hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;    // 50%占空比
    hi2c1.Init.OwnAddress1 = 0x00;             // 无自定义地址
    hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT; // 7位地址模式
    hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE; // 禁用双地址模式
    hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE; // 禁用通用呼叫
    hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE; // 禁止时钟伸展

    if (HAL_I2C_Init(&hi2c1) != HAL_OK)
    {
        Error_Handler();  // 初始化失败时的错误处理
    }
}

// I2C 读取数据函数
HAL_StatusTypeDef I2C_ReadData(uint16_t DevAddress, uint8_t *pData, uint16_t Size)
{
    return HAL_I2C_Master_Receive(&hi2c1, DevAddress, pData, Size, HAL_MAX_DELAY);
}

// I2C 写入数据函数
HAL_StatusTypeDef I2C_WriteData(uint16_t DevAddress, uint8_t *pData, uint16_t Size)
{
    return HAL_I2C_Master_Transmit(&hi2c1, DevAddress, pData, Size, HAL_MAX_DELAY);
}
