#include "usart.h"
#include "gpio.h"
#include "stm32f4xx_hal.h"

// USART2 端口定义（用于 PM2.5 和 Pixhawk 通信）
extern UART_HandleTypeDef huart2; 

// USART3 端口定义（用于 NB-IoT 通信）
extern UART_HandleTypeDef huart3;

// USART2 初始化配置函数
void MX_USART2_UART_Init(void)
{
    huart2.Instance = USART2;
    huart2.Init.BaudRate = 9600;          // 设置波特率
    huart2.Init.WordLength = UART_WORDLENGTH_8B;  // 字长 8 位
    huart2.Init.StopBits = UART_STOPBITS_1;       // 停止位 1
    huart2.Init.Parity = UART_PARITY_NONE;        // 无校验
    huart2.Init.Mode = UART_MODE_TX_RX;           // 使能发送接收
    huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;  // 不使用硬件流控制
    huart2.Init.OverSampling = UART_OVERSAMPLING_16;  // 16倍过采样
    if (HAL_UART_Init(&huart2) != HAL_OK)
    {
        Error_Handler();  // 初始化失败时的错误处理
    }
}

// USART3 初始化配置函数（用于 NB-IoT 模块）
void MX_USART3_UART_Init(void)
{
    huart3.Instance = USART3;
    huart3.Init.BaudRate = 115200;        // 设置波特率
    huart3.Init.WordLength = UART_WORDLENGTH_8B;  // 字长 8 位
    huart3.Init.StopBits = UART_STOPBITS_1;       // 停止位 1
    huart3.Init.Parity = UART_PARITY_NONE;        // 无校验
    huart3.Init.Mode = UART_MODE_TX_RX;           // 使能发送接收
    huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;  // 不使用硬件流控制
    huart3.Init.OverSampling = UART_OVERSAMPLING_16;  // 16倍过采样
    if (HAL_UART_Init(&huart3) != HAL_OK)
    {
        Error_Handler();  // 初始化失败时的错误处理
    }
}

// USART 数据发送函数
void UART_SendString(UART_HandleTypeDef *huart, const char *str)
{
    while (*str)
    {
        // 发送一个字符
        HAL_UART_Transmit(huart, (uint8_t *)str++, 1, HAL_MAX_DELAY);
    }
}

// USART 接收数据函数
void UART_ReceiveString(UART_HandleTypeDef *huart, char *buffer, uint16_t size)
{
    HAL_UART_Receive(huart, (uint8_t *)buffer, size, HAL_MAX_DELAY);
}

// 错误处理函数
void Error_Handler(void)
{
    __disable_irq();
    while (1)
    {
    }
}
