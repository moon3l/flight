#include "nbiot.h"
#include "usart.h"

// NB-IoT 模块初始化
void NB_IoT_Init(void)
{
    // 发送 AT 指令初始化 NB-IoT 模块
    UART_SendString("AT+CSQ\r\n");    // 查询信号质量
    HAL_Delay(1000);
    UART_SendString("AT+CGATT=1\r\n");  // 建立连接
    HAL_Delay(1000);
    UART_SendString("AT+CGDCONT=1,\"IP\",\"CMNET\"\r\n"); // 设置接入点
    HAL_Delay(1000);
}

// 数据上传到云端
void NB_IoT_SendData(SensorData_t *data)
{
    char buffer[512];
    snprintf(buffer, sizeof(buffer), "POST /data HTTP/1.1\r\nHost: yourcloudserver.com\r\nContent-Type: application/json\r\n\r\n{\"CO2\":%d, \"TVOC\":%d, \"PM2_5\":%d, \"Temperature\":%.2f, \"Humidity\":%.2f, \"Light\":%d, \"Noise\":%d}",
             data->CO2, data->TVOC, data->PM2_5, data->temperature, data->humidity, data->light, data->noise);

    // 发送 HTTP 请求
    UART_SendString(buffer);
}
