#include "main.h"
#include "sensor.h"
#include "nbiot.h"
#include "flight.h"
#include "usart.h"
#include "i2c.h"
#include "adc.h"
#include "gpio.h"

SensorData_t envData;

int main(void)
{
    HAL_Init();                 // 初始化HAL库
    SystemClock_Config();      // 配置系统时钟

    MX_GPIO_Init();            // 初始化 GPIO
    MX_USART2_UART_Init();     // UART2: PM2.5、飞控通信
    MX_USART3_UART_Init();     // UART3: NB-IoT通信
    MX_I2C1_Init();            // I2C1: CO2/TVOC、光照、温湿度
    MX_ADC1_Init();            // ADC: 模拟传感器，如噪声

    Sensor_Init();             // 初始化传感器
    NB_IoT_Init();             // 初始化 NB-IoT 通信
    Flight_Init();             // 初始化飞行相关功能（与Pixhawk通信）

    while (1)
    {
        Sensor_ReadAll(&envData);       // 读取所有传感器数据
        NB_IoT_SendData(&envData);      // 上传数据至云端
        Flight_AutoNavigate();          // 自动导航逻辑（如定时触发）
        
        HAL_Delay(5000);                // 延时5秒，视情况调整采样频率
    }
}
