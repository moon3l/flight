#include "flight.h"
#include "usart.h"
#include "gpio.h"
#include "math.h"

// 假设飞行路径为一系列航点（简化模型：点的坐标为 (x, y)）
#define MAX_WAYPOINTS 10  // 最大航点数
#define HOME_X 0          // 起点坐标（X）
#define HOME_Y 0          // 起点坐标（Y）

typedef struct
{
    float x;
    float y;
} Waypoint_t;

Waypoint_t waypoints[MAX_WAYPOINTS];  // 存储路径点
uint8_t waypointCount = 0;             // 路径点计数

// 飞行初始化
void Flight_Init(void)
{
    // 初始化 Pixhawk 通信（通过 USART）
    USART_SendString("MAVLINK_START\r\n");   // 启动飞行控制器
    HAL_Delay(500);

    // 初始化路径规划（假设只使用简单的2D坐标）
    waypointCount = 3;
    waypoints[0].x = 1.0; waypoints[0].y = 2.0;
    waypoints[1].x = 4.0; waypoints[1].y = 5.0;
    waypoints[2].x = 7.0; waypoints[2].y = 8.0;
}

// 简单的贪心路径规划：寻找最近的下一个航点
Waypoint_t Flight_GetNextWaypoint(float currentX, float currentY)
{
    float minDistance = INFINITY;
    uint8_t nextWaypointIndex = 0;

    for (uint8_t i = 0; i < waypointCount; i++)
    {
        float dist = sqrt(pow((waypoints[i].x - currentX), 2) + pow((waypoints[i].y - currentY), 2));
        if (dist < minDistance)
        {
            minDistance = dist;
            nextWaypointIndex = i;
        }
    }

    return waypoints[nextWaypointIndex];
}

// 飞行任务：执行路径规划与巡检
void Flight_StartMission(float currentX, float currentY)
{
    Waypoint_t nextWaypoint;

    // 循环直到所有航点都访问
    while (waypointCount > 0)
    {
        // 获取下一个航点
        nextWaypoint = Flight_GetNextWaypoint(currentX, currentY);

        // 控制飞行器到达下一个航点（这里是模拟发送 MAVLink 命令）
        char command[50];
        snprintf(command, sizeof(command), "MAVLINK_GOTO_X%.2f_Y%.2f\r\n", nextWaypoint.x, nextWaypoint.y);
        USART_SendString(command);

        // 假设飞行器到达目标点后更新当前位置
        currentX = nextWaypoint.x;
        currentY = nextWaypoint.y;

        // 任务完成后从路径中删除已访问的航点
        waypointCount--;
        waypoints[nextWaypointIndex] = waypoints[waypointCount];  // 删除航点
        HAL_Delay(2000);  // 模拟到达目的地后的停留时间
    }
}

// 飞行任务：返回起点
void Flight_ReturnHome(void)
{
    // 发送指令返回起点
    char returnCommand[50];
    snprintf(returnCommand, sizeof(returnCommand), "MAVLINK_RETURN_HOME_X%.2f_Y%.2f\r\n", HOME_X, HOME_Y);
    USART_SendString(returnCommand);
    HAL_Delay(3000);  // 等待飞行器返回起点
    USART_SendString("MAVLINK_TASK_COMPLETE\r\n");  // 标记任务完成
}

// 自动导航功能（控制飞行到目标点并完成任务）
void Flight_AutoNavigate(float currentX, float currentY)
{
    // 开始执行任务
    Flight_StartMission(currentX, currentY);

    // 任务完成后返回起点
    Flight_ReturnHome();
}
