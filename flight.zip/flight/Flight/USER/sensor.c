#include "sensor.h"
#include "i2c.h"
#include "usart.h"
#include "adc.h"

// 模拟传感器数据结构
SensorData_t envData;

void Sensor_Init(void)
{
    // 初始化 CO2/TVOC 传感器
    SGP30_Init();
    // 初始化 PM2.5 传感器
    PMS5003_Init();
    // 初始化温湿度传感器
    DHT22_Init();
    // 初始化光照传感器
    BH1750_Init();
    // 初始化噪声传感器（模拟量）
    NoiseSensor_Init();
}

void Sensor_ReadAll(SensorData_t *data)
{
    // 读取 CO2/TVOC 数据
    data->CO2 = SGP30_Read_CO2();
    data->TVOC = SGP30_Read_TVOC();
    
    // 读取 PM2.5 数据
    data->PM2_5 = PMS5003_Read_PM2_5();
    
    // 读取温湿度数据
    data->temperature = DHT22_Read_Temperature();
    data->humidity = DHT22_Read_Humidity();
    
    // 读取光照数据
    data->light = BH1750_Read_LightIntensity();
    
    // 读取噪声数据
    data->noise = NoiseSensor_Read_Level();
}
